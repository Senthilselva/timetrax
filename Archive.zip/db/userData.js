const userData = [
    {
        id: 1,
        role: "Admin",
        firstname: "Gracie",
        lastname: "Diaz",
        username: "gudiaz",
        email: "gudiaz@msn.com",
        address: "123 Paradise Ln",
        city: "Heaven",
        state: "NJ",
        zip: "08812",
        phone: "732-979-7252",
        hourlywage: '$100'
    },
    {
        id: 2,
        role: 'Admin',
        firstname: 'Senthil',
        lastname: 'Selvakumar',
        username: 'senthil',
        email: 'senthil@test.com',
        hourlywage: '$100'
    },
    {
        id: 3,
        role: 'Admin',
        firstname: 'Zeynep',
        lastname: 'Ozdemir',
        username: 'zeynep',
        email: 'zeynep@test.com',
        hourlywage: '$100'
    }
];

module.exports = userData;