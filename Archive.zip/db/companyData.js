const companyData = [
    {
        id: 1,
        name: "Loeffler Pools",
        address: "7 Ridge Road",
        city: "Green Brook",
        state: "NJ",
        zip: "08812",
        contactname: "Tom Loeffler",
        contactphone: "732-968-8069",
        contactemail: "LoefflerPools@gmail.com"
    }
];

module.exports = companyData;