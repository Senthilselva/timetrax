const jobData = [
    {
        id: 1,
        name: "Trump National Golf Club",
        address: "900 Lamington Rd",
        city: "Bedminster Township",
        state: "NJ",
        zip: "07921",
        contactname: "Camille Loeffler",
        contactphone: "732-968-8069",
        contactemail: "LoefflerPools@gmail.com"
    },
    {
        id: 2,
        name: "Maplewood Country Club",
        address: "28 Baker St",
        city: "Maplewood",
        state: "NJ",
        zip: "07040",
        contactname: "Camille Loeffler",
        contactphone: "732-968-8069",
        contactemail: "LoefflerPools@msn.com"
    }
];

module.exports = jobData;