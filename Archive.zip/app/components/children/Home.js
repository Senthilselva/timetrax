import React from "react";
//auth function
import Auth  from "./Auth";


class Home extends React.Component {
	constructor(props) {
        super(props);
    }

    render() {
    	return <h1>Time Trax</h1>
  	}
}

// Export the component back for use in other files
export default Home;