import React, {Component} from "react";

class Home extends Component {
	constructor(props) {
        super(props);
    }

    render() {
    	return <h1>Time Trax</h1>
  	}
}
