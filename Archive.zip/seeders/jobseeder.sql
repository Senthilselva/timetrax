INSERT INTO JOBS (name, address, city, state, zip, 
contactname,contactphone, contactemail, createdAt,updatedAt) VALUES 
('YMCA',' Rose rd', 'Trenton', 'NJ',
'08817', 'kate','908-123-4567','kate@mypool.com',CURDATE(),CURDATE());
